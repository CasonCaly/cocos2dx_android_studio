﻿using System;

namespace Scx
{
	public class RPCData
	{
		public RPCData ()
		{
		}
	}
}

