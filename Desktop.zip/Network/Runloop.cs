﻿using System;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Scx{

	public class RunloopObserver{
		public virtual void Operate(){}
	}

	public class Runloop{
	
		private static RunLoop s_instance = null;

		private object m_lock = new object();
		private Queue<RunloopObserver> m_queue = new Queue<RunloopObserver>();

		public static RunLoop Instance(){
			if (null == s_instance) {
				s_instance = new Runloop ();
			}
			return s_instance;
		}

		private Runloop (){
			vp_Timer.In(0.0f, () => {
				this.Update();
			});
		}

		private void AddObserver(RunloopObserver observer){
			lock (m_lock) {
				m_queue.Enqueue (observer);
			}
		}

		private RunloopObserver Front (){
			lock (m_lock) {
				if (m_queue.Count == 0)
					return null;
				return m_queue.Peek ();
			}
		}

		private void Pop(){
			lock (m_lock) {
				if (m_queue.Count == 0)
					return null;
				return m_queue.Dequeue();
			}
		}

		private void Update(){
			RunloopObserver observer = null;
			do {
				observer = this.Front ();
				if(null == observer)
					break;
				observer.Operate();
				this.Pop();
			} while (true);
		}

		public static void Add(RunloopObserver observer){
			Runloop.Instance ().AddObserver (observer);
		}
	}
}

