﻿using UnityEngine;
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Collections.Generic;
using CommonUtility;

namespace Scx {

	public enum RPCRecvStep{
		GetHeaderSizeStep,
		RecvHeaderStep,
		RecvBodyStep
	}

	public enum RPCMsgType{
		Unknow,
		DidConnectResult,
		DidDisconnnect,
		DidOneRPCDataFinish,
		RPCDestory
	}

	public enum EnumDisType {
	    kException,
	    kDisconnect,
	}

	public class RPCClientMsg : RunloopObserver{

		private RPCMsgType m_msgType = RPCMsgType.Unknow;
		private bool m_isSuccess = false;
		private MemoryStream m_rpcStream = null;
		private RPCClient m_client;

		public RPCClientMsg(RPCClient client){
			m_client = client;
		}

		public RPCMsgType MsgType{
			set { m_msgType = value; }
			get { return m_msgType;}
		}

		public bool IsSuccess{
			set { m_msgType = value; }
			get { return m_msgType; }
		}

		public MemoryStream RPCData{
			set { m_rpcStream = value; }
			get { return m_rpcStream; }
		}

		public RPCClient RPCClient{
			set { m_client = value; }
			get { return m_client; }
		}

		public virtual void Operate(){
			m_client.OnRunLoop (this);
		}
	}

	public class RPCClient {
		public static bool s_loggedIn = false;
		public static int HeadSize = 4;

		private TcpClient m_client = null;
		private NetworkStream m_netStream = null;
		private MemoryStream m_rpcStream = null;
		private RPCRecvStep m_recvStep = RPCRecvStep.RecvHeaderStep;
		private BinaryReader m_reader;

	    private const int MAX_READ = 8192;
		private byte[] m_byteBuffer = null;

	    // Use this for initialization
		public RPCClient() {
	    }
			

	    /// <summary>
	    /// 移除代理
	    /// </summary>
	    public void OnRemove() {
	        this.Close();
	        m_reader.Close();
			m_rpcStream.Close();
	    }

	    /// <summary>
	    /// 连接服务器
	    /// </summary>
	    void ConnectServer(string host, int port) {
			vp_Timer.In(0.0f, () => {
				this.OnRunLoop();
			});

	        m_client = null;
	        m_client = new TcpClient();
	        m_client.SendTimeout = 1000;
	        m_client.ReceiveTimeout = 1000;
	        m_client.NoDelay = true;

	        try {
	            m_client.BeginConnect(host, port, new AsyncCallback(OnConnect), null);
	        } catch (Exception e) {
	            Close(); 
				Debug.LogError(e.Message);
	        }
	    }

	    /// <summary>
	    /// 连接上服务器
	    /// </summary>
		void OnConnect(IAsyncResult asr) {
			bool isConnected = m_client.Connected;
			if (isConnected) {
				m_byteBuffer = new byte[MAX_READ];
				m_netStream = m_client.GetStream ();
				m_reader = new BinaryReader (m_netStream);
				m_netStream.BeginRead (m_byteBuffer, 0, MAX_READ, new AsyncCallback (OnRead), null);
				m_client.EndConnect (asr);
			}
			else {
				m_client.EndConnect (asr);
			}

			RPCClientMsg msg = new RPCClientMsg (this);
			msg.MsgType = RPCMsgType.DidConnectResult;
			msg.IsSuccess = isConnected;
			Runloop.Add (msg);
	    }

		/// <summary>
		/// 读取消息
		/// </summary>
		void OnRead(IAsyncResult asr) {
			int bytesRead = 0;
			try {
				bytesRead = m_netStream.EndRead(asr);
				if (bytesRead <= 0) {                //包尺寸有问题，断线处理
					this.OnDisconnected(EnumDisType.kDisconnect, "bytesRead < 1");
					return;
				}

				this.OnReceive(m_byteBuffer, bytesRead);   //分析数据包内容，抛给逻辑层
				Array.Clear(m_byteBuffer, 0, m_byteBuffer.Length);   //清空数组
				m_netStream.BeginRead(m_byteBuffer, 0, MAX_READ, new AsyncCallback(OnRead), null);
			} catch (Exception ex) {
				//PrintBytes();
				this.OnDisconnected(EnumDisType.kException, ex.Message);
			}
		}

		/// <summary>
		/// 接收到消息
		/// </summary>
		void OnReceive(byte[] bytes, int size) {

			do {
				if(RPCRecvStep.GetHeaderSizeStep == m_recvStep){
					m_rpcStream = new MemoryStream();
					m_recvStep = RPCRecvStep.GetHeaderSizeStep;
				}

				if(RPCRecvStep.RecvHeaderStep == m_recvStep){
					m_rpcStream.W
				}

				if(RPCRecvStep.RecvBodyStep == m_recvStep){
					
				}
				
			} while(size > 0);
		}

	    /// <summary>
	    /// 写数据
	    /// </summary>
	    void WriteMessage(byte[] message) {
	        MemoryStream ms = null;
	        using (ms = new MemoryStream()) {
	            ms.Position = 0;
	            BinaryWriter writer = new BinaryWriter(ms);
				ushort msglen = (ushort)(message.Length +  2); 
				if (AppConst.SERVER_ENDIAN == AppConst.EnumSeverEndianMode.kBigEndian) {
					msglen = Converter.GetBigEndian (msglen);
				}
	            writer.Write(msglen);
	            writer.Write(message);
	            writer.Flush();
	            if (m_client != null && m_client.Connected) {
	                //NetworkStream stream = client.GetStream(); 
	                byte[] payload = ms.ToArray();
					m_netStream.BeginWrite(payload, 0, payload.Length, new AsyncCallback(OnWrite), null);
	            } else {
	                Debug.LogError("client.connected----->>false");
	            }
	        }
	    }

	   

	    /// <summary>
	    /// 丢失链接
	    /// </summary>
	    void OnDisconnected(EnumDisType dis, string msg) {
	        Close();   //关掉客户端链接
	        int protocal = dis == EnumDisType.kException ?
	        Protocal.Exception : Protocal.Disconnect;

	        ByteBuffer buffer = new ByteBuffer();
	        buffer.WriteShort((ushort)protocal);
	        NetworkManager.AddEvent(protocal, buffer);
	        Debug.LogError("Connection was closed by the server:>" + msg + " Distype:>" + dis);
	    }

	    /// <summary>
	    /// 打印字节
	    /// </summary>
	    /// <param name="bytes"></param>
	    void PrintBytes() {
	        string returnStr = string.Empty;
	        for (int i = 0; i < m_byteBuffer.Length; i++) {
	            returnStr += m_byteBuffer[i].ToString("X2");
	        }
	        Debug.LogError(returnStr);
	    }

	    /// <summary>
	    /// 向链接写入数据流
	    /// </summary>
	    void OnWrite(IAsyncResult r) {
	        try {
				m_netStream.EndWrite(r);
	        } catch (Exception ex) {
	            Debug.LogError("OnWrite--->>>" + ex.Message);
	        }
	    }



	    /// <summary>
	    /// 剩余的字节
	    /// </summary>
	    private long RemainingBytes() {
			return m_netStream.Length - m_netStream.Position;
	    }

	    /// <summary>
	    /// 接收到消息
	    /// </summary>
	    /// <param name="ms"></param>
	    void OnReceivedMessage(MemoryStream ms) {
	        BinaryReader r = new BinaryReader(ms);
	        byte[] message = r.ReadBytes((int)(ms.Length - ms.Position));
	        //int msglen = message.Length;

	        ByteBuffer buffer = new ByteBuffer(message);
	        int mainId = buffer.ReadShort();
	        NetworkManager.AddEvent(mainId, buffer);
	    }


	    /// <summary>
	    /// 会话发送
	    /// </summary>
	    void SessionSend(byte[] bytes) {
	        WriteMessage(bytes);
	    }

	    /// <summary>
	    /// 关闭链接
	    /// </summary>
	    public void Close() {
	        if (m_client != null) {
	            if (m_client.Connected) 
					m_client.Close();
	            m_client = null;
	        }
	        s_loggedIn = false;
	    }

	    /// <summary>
	    /// 发送连接请求
	    /// </summary>
	    public void SendConnect() {
	        //ConnectServer(AppConst.SocketAddress, AppConst.SocketPort);
	    }

	    /// <summary>
	    /// 发送消息
	    /// </summary>
	    public void SendMessage(ByteBuffer buffer) {
	        SessionSend(buffer.ToBytes());
	        buffer.Close();
	    }

		public void OnRunLoop(RPCClientMsg msg){
			RPCMsgType msgType = msg.MsgType;

			if (RPCMsgType.DidConnectResult == msgType) {
			
			} else if (RPCMsgType.DidOneRPCDataFinish == msgType) {
			
			} else if (RPCMsgType.DidDisconnnect == msgType) {
			
			}	
		}
	}
}