#include "SCXPipe.h"
#ifdef WIN32
#include <windows.h>
#include <WinSock.h>

#else
#include <sys/socket.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>

#endif

#ifdef WIN32
int pipe(int fildes[2])
{
	int tcp1, tcp2;
	sockaddr_in name;
	memset(&name, 0, sizeof(name));
	name.sin_family = AF_INET;
	name.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
	int namelen = sizeof(name);
	tcp1 = tcp2 = -1;
	int tcp = socket(AF_INET, SOCK_STREAM, 0);
	if (tcp == -1){
		goto clean;
	}
	if (bind(tcp, (sockaddr*)&name, namelen) == -1){
		goto clean;
	}
	if (listen(tcp, 5) == -1){
		goto clean;
	}
	if (getsockname(tcp, (sockaddr*)&name, &namelen) == -1){
		goto clean;
	}
	tcp1 = socket(AF_INET, SOCK_STREAM, 0);
	if (tcp1 == -1){
		goto clean;
	}
	if (-1 == connect(tcp1, (sockaddr*)&name, namelen)){
		goto clean;
	}
	tcp2 = accept(tcp, (sockaddr*)&name, &namelen);
	if (tcp2 == -1){
		goto clean;
	}
	if (closesocket(tcp) == -1){
		goto clean;
	}
	fildes[0] = tcp1;
	fildes[1] = tcp2;
	return 0;
clean:
	if (tcp != -1){
		closesocket(tcp);
	}
	if (tcp2 != -1){
		closesocket(tcp2);
	}
	if (tcp1 != -1){
		closesocket(tcp1);
	}
	return -1;
}

#endif
NS_SCX_BEGIN
Pipe::Pipe(){
	m_fd[0] = -1;
	m_fd[1] = -1;
}

bool Pipe::init(){
	int result = pipe(m_fd);

#ifdef WIN32
	unsigned long mode = 1;
	ioctlsocket(m_fd[0], FIONBIO, &mode);
	ioctlsocket(m_fd[1], FIONBIO, &mode);
#else

	int flags = fcntl(m_fd[0], F_GETFL, 0);
	flags = flags | O_NONBLOCK;
	fcntl(m_fd[0], F_SETFL, flags);	

	flags = fcntl(m_fd[1], F_GETFL, 0);
	flags = flags | O_NONBLOCK;
	fcntl(m_fd[1], F_SETFL, flags);	
#endif

	return result != -1;
}

void Pipe::write(unsigned char* data, int len){

	if(-1 != m_fd[1])
#if defined(WIN32)
		::send(m_fd[1], (char*)data, len, 0);
#else
		::write(m_fd[1], (char*)data, len);
#endif
}

int Pipe::read(unsigned char* data, int len){
	
	if(-1 != m_fd[0] ){
#if defined(WIN32)
		return ::recv(m_fd[0], (char*)data, len, 0);
#else
		return (int)::read(m_fd[0], (char*)data, len);
#endif
	}
	else{
		return -1;
	}
}

void Pipe::close(){
#ifdef WIN32
	if(-1 != m_fd[0])
		::closesocket(m_fd[0]);
	if(-1 != m_fd[1])
		::closesocket(m_fd[1]);
#else
	if(-1 != m_fd[0])
		::close(m_fd[0]);
	if(-1 != m_fd[1])
		::close(m_fd[1]);
#endif
}

int Pipe::readFd(){
	return m_fd[0];
}

int Pipe::writeFd(){
	return m_fd[1];
}
NS_SCX_END