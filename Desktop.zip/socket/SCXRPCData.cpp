#include "SCXRPCData.h"
NS_SCX_BEGIN
RPCData::RPCData(){
	m_isDataFinished = false;
	m_isBodyFinished = false;
	m_isHeaderFinished = false;
}

void RPCData::allocHeaderData(int size){
	m_headerData.allocData(size);
}

void RPCData::allocBodyData(int size){
	m_bodyData.allocData(size);
}

int RPCData::appendHeaderData(unsigned char* data, int size){
	
	int dataSize = m_headerData.getDataSize();
	int bufferSize = m_headerData.getBufferSize();
	int copySize = size;

	if ( (dataSize + size) >= bufferSize ){
		copySize = bufferSize - dataSize;
		m_isHeaderFinished = true;
	}

	m_headerData.appendData(data, copySize);
	return copySize;
}

int RPCData::appendBodyData(unsigned char* data, int size){
	int dataSize = m_bodyData.getDataSize();
	int bufferSize = m_bodyData.getBufferSize();
	int copySize = size;

	if ( (dataSize + size) >= bufferSize ){
		copySize = bufferSize - dataSize;
		m_isBodyFinished = true;
	}

	m_bodyData.appendData(data, copySize);
	return copySize;
}

SocketData* RPCData::getHeaderData(){
	return &m_headerData;
}

SocketData* RPCData::getBodyData(){
	return &m_bodyData;
}

void RPCData::setIsDataFinished(bool isFinished){
	m_isDataFinished = isFinished;
}

bool RPCData::getIsDataFinished(){
	return m_isDataFinished;
}

bool RPCData::getIsBodyFinished(){
	return m_isBodyFinished;
}

bool RPCData::getIsHeaderFinished(){
	return m_isHeaderFinished;
}
NS_SCX_END