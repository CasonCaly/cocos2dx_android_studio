////////////////////////////////////////////////////////////
// Copyright(c) 2015���ݲ�����������Ƽ����޹�˾
// Author��  zhuang yusong
// Created�� 2015/06/11
// Describe��RPC���ݷ�װ��
////////////////////////////////////////////////////////////

#ifndef SCX_RPC_DATA_H
#define SCX_RPC_DATA_H

#include "SCXSocketData.h"

NS_SCX_BEGIN

class SCX_CORE_DLL RPCData : public Ref{

public:

	RPCData();

	void allocHeaderData(int size);

	void allocBodyData(int size);

	int appendHeaderData(unsigned char* data, int size);

	int appendBodyData(unsigned char* data, int size);

	SocketData* getHeaderData();

	SocketData* getBodyData();

	void setIsDataFinished(bool isFinished);

	bool getIsDataFinished();

	bool getIsBodyFinished();

	bool getIsHeaderFinished();

protected:

	SocketData m_headerData;

	SocketData m_bodyData;

	bool		 m_isDataFinished;

	bool		 m_isBodyFinished;

	bool		 m_isHeaderFinished;

};
NS_SCX_END
#endif