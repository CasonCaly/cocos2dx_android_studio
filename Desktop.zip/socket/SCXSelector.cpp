#include "SCXSelector.h"
#include "SCXSocketChannel.h"
NS_SCX_BEGIN
Selector* Selector::open(){
	Selector* selector = new Selector();
	selector->init();
	return selector;
}

Selector::Selector(){
	m_pipeReadData = 0;
	m_maxSocket = 0;
}

void Selector::init(){
	m_pipe.init();
	FD_ZERO(&m_readSet);
	FD_ZERO(&m_writeSet);
	FD_SET(m_pipe.readFd(), &m_readSet);
	m_maxSocket = 1;
}

void resister(SocketChannel* channel){

}

int Selector::select(){
	return this->select(Selector::MaxWaitTime);
}

int Selector::select(int millionSecond){
	
	int recvResult = 0;
	if(millionSecond < 0){
		recvResult = ::select(FD_SETSIZE, &m_readSet, &m_writeSet, nullptr, nullptr);
	}
	else{
		timeval timeout;
		timeout.tv_sec = millionSecond/1000;
        timeout.tv_usec = (millionSecond%1000) * 1000;
		recvResult = ::select(FD_SETSIZE,  &m_readSet, &m_writeSet, nullptr, &timeout);
	}

  	bool isPipe = FD_ISSET(m_pipe.readFd(), &m_readSet) != 0;
	if(isPipe){ 
		m_mutex.lock();
		m_pipe.read((unsigned char*)&m_pipeReadData, sizeof(int));
		m_pipeReadData = 0;
		m_mutex.unlock();
	}

	FD_SET(m_pipe.readFd(), &m_readSet);
	return recvResult;
}

void Selector::wakeup(){
	m_mutex.lock();
	if(m_pipeReadData == 0){
		m_pipeReadData = Selector::WakeUpData;
		m_pipe.write((unsigned char*)&m_pipeReadData, sizeof(int));
	}
	m_mutex.unlock();
}

void Selector::insert(SocketChannel* channel){
	std::set<SocketChannel*>::iterator target = m_channels.find(channel);
	if(target == m_channels.end()){
		m_channels.insert(channel);
		m_maxSocket++;
		channel->setReadAnWriteSet(&m_readSet, &m_writeSet);
	}

	this->fdSet(channel);
}

void Selector::close(){
	m_pipe.close();
	this->release();
}

void Selector::erase(SocketChannel* channel){
	std::set<SocketChannel*>::iterator target = m_channels.find(channel);
	if(target != m_channels.end())
		m_channels.erase(target);
}

void Selector::fdSet(SocketChannel* channel){
	int socket = channel->socket();
	int key = channel->selectionKey();
	FD_CLR(socket, &m_readSet);	
	FD_CLR(socket, &m_writeSet); 
	if( key & SocketChannel::OP_READ )
		FD_SET(socket , &m_readSet);

	if ( (key & SocketChannel::OP_WRITE) || (key & SocketChannel::OP_CONNECT) )
		FD_SET(socket , &m_writeSet);
}
NS_SCX_END