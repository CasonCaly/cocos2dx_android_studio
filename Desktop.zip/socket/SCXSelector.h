////////////////////////////////////////////////////////////
// Copyright(c) 2015���ݲ�����������Ƽ����޹�˾
// Author��  zhuang yusong
// Created�� 2015/06/11
// Describe���첽io���õ�select�����ķ�װ
////////////////////////////////////////////////////////////

#ifndef SCX_SELECTOR_H
#define SCX_SELECTOR_H
#include <set>
using namespace std;
#include "socket/SCXPipe.h"
#include "thread/SCXMutex.h"

#ifndef WIN32
#include <sys/socket.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#endif

NS_SCX_BEGIN
class SocketChannel;
class SCX_CORE_DLL Selector : public Ref{

public:

	static Selector* open();

protected:

	Selector();

	void init();

public:

	int select();

	int select(int millionSecond);

	void wakeup();

	void insert(SocketChannel* channel);

	void erase(SocketChannel* channel);

	void close();

protected:


	void fdSet(SocketChannel* channel);

protected:

	fd_set m_readSet;

	fd_set m_writeSet;

	Pipe m_pipe;

	std::set<SocketChannel*> m_channels;

protected:

	int m_pipeReadData;

	Mutex m_mutex;

	int m_maxSocket;

protected:

	const static int WakeUpData = 1;

public:

	const static int MaxWaitTime = -1;
};
NS_SCX_END
#endif
