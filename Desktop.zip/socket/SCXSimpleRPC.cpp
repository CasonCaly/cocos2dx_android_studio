#include "SCXSimpleRPC.h"
#include "connectivity/SCXConnectivity.h"

NS_SCX_BEGIN
SimpleRPCMsg::SimpleRPCMsg(){
	m_type = SCXSimpleRPCDidConnectResult;
	m_isSuccess = false;
	m_rpcData = nullptr;
	m_simpleRPC = nullptr;
}

SimpleRPCMsg::~SimpleRPCMsg(){
	if(nullptr != m_rpcData)
		m_rpcData->release();
}

void SimpleRPCMsg::setType(SimpleRPCMsgType type){
	m_type = type;
}

SimpleRPCMsgType SimpleRPCMsg::getType(){
	return m_type;
}

bool SimpleRPCMsg::getIsSuccess(){
	return m_isSuccess;
}

void SimpleRPCMsg::setIsSuccess(bool isSuccess){
	m_isSuccess = isSuccess;
}

void SimpleRPCMsg::setRPCData(RPCData* data){
	m_rpcData = data;
}

RPCData* SimpleRPCMsg::getRPCData(){
	return m_rpcData;
}

void SimpleRPCMsg::setSimpleRPC(SimpleRPC* rpc){
	m_simpleRPC = rpc;
}

void SimpleRPCMsg::operate(){
	m_simpleRPC->rpcRunloop(this);
}

//////////////////////////////////////////////////////
SimpleRPC::SimpleRPC(){

	m_delegate =  nullptr;
	m_recvStep = SCXSimpleRPCGetHeaderSizeStep;
	m_heartBeatTime = 10;//
	m_isConnect = false;
	m_isConnecting = false;
	m_isDisconnect = false;

	m_selector = nullptr;
	m_socketChannel = nullptr;

	m_connectTimeout = 10;
	m_recvTimeout = 15;
	m_selectStep = SCXSimpleRPCSelectConnect;
	m_destory = false;
}

SimpleRPC::~SimpleRPC(){

}

void SimpleRPC::init(const char* host, int port){
	m_host = host;
	m_port = port;
}

void SimpleRPC::start(){
	if (m_isDisconnect){
		this->didConnectResult(false);
		return;
	}

	if(Connectivity::isNetworkConnected()){
		m_socketChannel = SocketChannel::open();
		m_selector = Selector::open();
		m_socketChannel->configureBlocking(false);
		m_thread.setDelegate(this);
		m_thread.start();
		m_isConnecting = true;
		m_selector->wakeup();
	}
	else{
		this->didConnectResult(false);
	}
}

void SimpleRPC::restart(){
	if(m_isConnecting || m_isConnect){
		return;
	}

	if(Connectivity::isNetworkConnected()){
		if(nullptr == m_selector){
			this->start();
		}
		else{
			m_selector->erase(m_socketChannel);
			m_socketChannel = SocketChannel::open();
			m_socketChannel->configureBlocking(false);
			m_isConnecting = true;
			m_selector->wakeup();
		}	
	}
	else{
		this->didConnectResult(false);
	}
}

void SimpleRPC::stop(){

}

void SimpleRPC::destory(){
	m_lock.lock();
	m_destory = true;
	m_lock.unlock();
	if(m_selector)
		m_selector->wakeup();
	else{
		this->clean();
	}
}

void SimpleRPC::sendData(unsigned char* data, int size){
	if(!m_isConnect || m_destory)
		return;

	SocketData* socketData = new SocketData();
	socketData->setData(data, size);
	this->pushSendData(socketData);
}

void SimpleRPC::sendData(SocketData* data){
	if (data){
		if (m_isDisconnect){
			data->release();
		}
		else{
			data->retain();
			this->pushSendData(data);
		}
	}
}

void SimpleRPC::setHeartBeatTime(int time){
	m_heartBeatTime = time;
}

void SimpleRPC::setConnectTimeout(int cnnnTime){
	m_connectTimeout = cnnnTime;
}

void SimpleRPC::setRecvTimeout(int recvTime){
	m_recvTimeout = recvTime;
}

int SimpleRPC::getPort(){
	return m_port;
}

const char* SimpleRPC::getHost(){
	return m_host.c_str();
}

bool SimpleRPC::isConnect(){
	return m_isConnect;
}

bool SimpleRPC::isConnecting(){
	return m_isConnecting;
}

void SimpleRPC::setDelegate(SimpleRPCDelegate* _delegate){
	SimpleRPCDelegate* oldDelegate = m_delegate;
	m_delegate = _delegate;
	if (m_delegate){
		Ref* obj = dynamic_cast<Ref*>(m_delegate);
		if(obj)	
			obj->retain();
	}

	if(oldDelegate){
		Ref* obj = dynamic_cast<Ref*>(oldDelegate);
		if(obj)
			obj->release();
		else
			delete oldDelegate;
	}
}

void SimpleRPC::didConnectResult(bool isSuccess){
	SimpleRPCMsg* msg = new SimpleRPCMsg();
	msg->setType(SCXSimpleRPCDidConnectResult);
	msg->setIsSuccess(isSuccess);
	msg->setSimpleRPC(this);
	RunLoop::getInstance()->addObserver(msg);
}

void SimpleRPC::didDisconnect(){
	SimpleRPCMsg* msg = new SimpleRPCMsg();
	msg->setType(SCXSimpleRPCDidDisconnnect);
	msg->setSimpleRPC(this);
	RunLoop::getInstance()->addObserver(msg);
}

void SimpleRPC::didRecvData(unsigned char* data, int size){

	do{
		if(SCXSimpleRPCGetHeaderSizeStep == m_recvStep){
			int nSize = m_delegate->getHeaderSize(this);
			m_curData = new RPCData();
			m_curData->allocHeaderData(nSize);
			m_recvStep = SCXSimpleRPCRecvHeaderStep;
		}
	
		if(SCXSimpleRPCRecvHeaderStep == m_recvStep){
			int copySize = m_curData->appendHeaderData(data, size);
			if( m_curData->getIsHeaderFinished() ){//ͷ��
				m_recvStep = SCXSimpleRPCRecvBodyStep;
				m_delegate->didHeaderFinished(this, m_curData->getHeaderData());
				int nBodySize = m_delegate->getBodySize(this, m_curData->getHeaderData());
				m_curData->allocBodyData(nBodySize);
			}
			data += copySize;//����data����ʼλ�ã�ͬʱ����data�Ĵ�С
			size -= copySize;
		}

		if(SCXSimpleRPCRecvBodyStep == m_recvStep){
			int copySize = m_curData->appendBodyData(data, size);
			if ( m_curData->getIsBodyFinished() ){
				SimpleRPCMsg* msg = new SimpleRPCMsg();
				msg->setType(SCXSimpleRPCDidOneRPCDataFinish);
				msg->setRPCData(m_curData);
				msg->setSimpleRPC(this);
				RunLoop::getInstance()->addObserver(msg);
				
				m_curData = nullptr;
				m_recvStep = SCXSimpleRPCGetHeaderSizeStep;
			}
			data += copySize;//����data����ʼλ�ã�ͬʱ����data�Ĵ�С
			size -= copySize;
		}
	}while(size > 0);

}

void SimpleRPC::rpcRunloop(SimpleRPCMsg* msg){

	SimpleRPCMsgType type = msg->getType();
	switch(type){
	case SCXSimpleRPCDidConnectResult:{
	    m_isConnect = msg->getIsSuccess();
	    m_isConnecting = false;
		m_isDisconnect = false;
	    if (!m_destory){
			if (m_isConnect){
				gettimeofday(&m_lastRecvTime, nullptr);
				this->scheduleRecvTimeout();
			}
		    m_delegate->didConnectResult(this, msg->getIsSuccess());
	    }
	}
		break;
	case SCXSimpleRPCDidDisconnnect:	{
		m_isConnect = false;
		m_isConnecting = false;
		m_isDisconnect = true;
		if(!m_destory)
			m_delegate->didDisconnect(this);

		}
		break;
	case SCXSimpleRPCDidOneRPCDataFinish:{
        if (!m_destory){
			gettimeofday(&m_lastRecvTime, nullptr);
			m_delegate->didOnePRCDataFinish(this, msg->getRPCData());
		}
		break;
		}
	case SCXSimpleRPCDestory:{
        Scheduler* scheduler = Director::getInstance()->getScheduler();
		scheduler->unschedule(CC_SCHEDULE_SELECTOR(SimpleRPC::recvTimeoutCallback), this);
		this->setDelegate(nullptr);
		this->release();
		break;
		}
	}
}

void SimpleRPC::run(Thread* thread){
	int waitTime = Selector::MaxWaitTime;
	unsigned char buffer[8192];
	m_lock.lock();
	while(!m_destory){
		m_lock.unlock();
		int result = m_selector->select(waitTime);
		if(result > 0){		

			waitTime = this->selectSuccess(buffer, 8192);	
		}
		else if(result == 0){//��ʱ��

			waitTime = this->selectTimeout();
		}
		else if(result < 0){//ʧ����

			waitTime = this->selectFail();
		}
		m_lock.lock();
	}
	m_lock.unlock();

	this->clean();
}


int SimpleRPC::selectConnect(){
	m_selectStep = SCXSimpleRPCSelectConnecting;		
	m_socketChannel->connect(m_host.c_str(), m_port);
	m_socketChannel->resister(m_selector, SocketChannel::OP_CONNECT);
	return m_connectTimeout * 1000;//���ӳ�ʱʱ��
}

int SimpleRPC::selectConnecting(){
	m_selectStep = SCXSimpleRPCReadAndWrite;		
	bool isSucess = m_socketChannel->isConnectable();
	this->didConnectResult(isSucess);		
	m_socketChannel->resister(m_selector, SocketChannel::OP_READ);
	return  Selector::MaxWaitTime;
}

int SimpleRPC::slectReadAndWrite(unsigned char* buffer, int size){
	int waitTime = Selector::MaxWaitTime;
	bool isRecvSuccess = true;
	if(m_socketChannel->isReadable()){
		int readSize = m_socketChannel->read(buffer, size);
		if(readSize > 0)
			this->didRecvData(buffer, readSize);
		else
			isRecvSuccess = false;
	}
	bool isSendSuccess = this->sendData();
	if(isRecvSuccess && isSendSuccess){
		m_socketChannel->resister(m_selector, SocketChannel::OP_READ);
		waitTime = m_heartBeatTime * 1000;//������ʱ��
	}
	else{
		m_socketChannel->resister(m_selector, 0);//�շ�ʧ�ܣ������� 
		waitTime = Selector::MaxWaitTime;
		this->didDisconnect();
		m_selectStep = SCXSimpleRPCSelectConnect;
	}
	return waitTime;
}

int SimpleRPC::selectSuccess(unsigned char* buffer, int size){
	int waitTime = Selector::MaxWaitTime;
	if(m_selectStep == SCXSimpleRPCSelectConnect){
		waitTime = this->selectConnect();
	}
	else if(m_selectStep == SCXSimpleRPCSelectConnecting){
		waitTime = this->selectConnecting();
	}
	else if(m_selectStep == SCXSimpleRPCReadAndWrite){
		waitTime = this->slectReadAndWrite(buffer, size);
	}
	return waitTime;
}

int SimpleRPC::selectTimeout(){
	int waitTime = Selector::MaxWaitTime;
	if(SCXSimpleRPCSelectConnecting == m_selectStep){
		m_selectStep = SCXSimpleRPCSelectConnect;
		this->didConnectResult(false);
		m_socketChannel->resister(m_selector, 0);
		waitTime = Selector::MaxWaitTime;
	}
	else if(SCXSimpleRPCReadAndWrite == m_selectStep){
		if (!m_isDisconnect){
			SocketData* data = m_delegate->getHeartBeatData(this);
			this->pushSendData(data);
			waitTime = m_heartBeatTime * 1000;//������ʱ��
			m_socketChannel->resister(m_selector, SocketChannel::OP_READ);
		}
	}	
	return waitTime;
}

int SimpleRPC::selectFail(){
	int waitTime = Selector::MaxWaitTime;
	if(SCXSimpleRPCSelectConnecting == m_selectStep){
		m_selectStep = SCXSimpleRPCSelectConnect;
		waitTime = Selector::MaxWaitTime;
		this->didConnectResult(false);
	}
	else if(SCXSimpleRPCReadAndWrite == m_selectStep){
		m_selectStep = SCXSimpleRPCSelectConnect;
		waitTime = Selector::MaxWaitTime;
		this->didDisconnect();
	}
	m_socketChannel->resister(m_selector, 0);
	
	return waitTime;
}

void SimpleRPC::pushSendData(SocketData* data){
	if(nullptr == data)
		return;
	m_lock.lock();
	m_queueData.push(data);
	if(m_queueData.size() == 1)
		m_selector->wakeup();
	m_lock.unlock();
}

SocketData* SimpleRPC::frontData(){
	SocketData* data = nullptr;
	m_lock.lock();
	if(m_queueData.size() > 0)
		data = m_queueData.front();

	m_lock.unlock();
	return data;
}

void SimpleRPC::popData(){
	m_lock.lock();
	if(m_queueData.size() > 0)
		m_queueData.pop();

	m_lock.unlock();
}

bool SimpleRPC::sendData(){
	SocketData* data = nullptr;
	bool isSuccess = true;
	while( (data = this->frontData()) ){
		int sendRet = m_socketChannel->write(data->getData(), data->getDataSize());	
		if(-1 == sendRet){
			isSuccess = false;
			break;
		}
		this->popData();
	}

	//����ʧ���ˣ��ͰѶ������
	if(!isSuccess){
		while( (data = this->frontData()) ){
			data->release();
			this->popData();
		}
	}
	return isSuccess;
}

void SimpleRPC::clean(){
	
	SocketData* data = nullptr;
	while( (data = this->frontData()) ){
		data->release();
		this->popData();
	}

	if(m_selector)
		m_selector->close();
	if(m_socketChannel)
		m_socketChannel->close();
	

	SimpleRPCMsg* msg = new SimpleRPCMsg();
	msg->setSimpleRPC(this);
	msg->setType(SCXSimpleRPCDestory);
	RunLoop::getInstance()->addObserver(msg);
}

void SimpleRPC::scheduleRecvTimeout(){
	Scheduler* scheduler = Director::getInstance()->getScheduler();
	scheduler->schedule(CC_SCHEDULE_SELECTOR(SimpleRPC::recvTimeoutCallback), this, m_recvTimeout, false);
}

void SimpleRPC::recvTimeoutCallback(float time){
	timeval curTime;
	gettimeofday(&curTime, nullptr);
	int timeDiff = (curTime.tv_sec * 1000 * 1000 + curTime.tv_usec) - (m_lastRecvTime.tv_sec * 1000 * 1000 + m_lastRecvTime.tv_usec);
	double ftimeDiff = (timeDiff * 1.0f) / (1000 * 1000);
	//���ճ�ʱ�ˣ�
	if (ftimeDiff >= m_recvTimeout){
		Scheduler* scheduler = Director::getInstance()->getScheduler();
		scheduler->unschedule(CC_SCHEDULE_SELECTOR(SimpleRPC::recvTimeoutCallback), this);
		this->didDisconnect();
	}
}
NS_SCX_END