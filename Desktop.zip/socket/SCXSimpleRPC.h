////////////////////////////////////////////////////////////
// Copyright(c) 2015���ݲ�����������Ƽ����޹�˾
// Author��  zhuang yusong
// Created�� 2015/06/11
// Describe��Զ�̹��̵���Э��RCP����
////////////////////////////////////////////////////////////

#ifndef SCX_SIMPLE_RPC_H
#define SCX_SIMPLE_RPC_H
#include <queue>
using namespace std;

#include "SCXRPCData.h"
#include "SCXSelector.h"
#include "SCXSocketChannel.h"
#include "thread/SCXRunLoop.h"
#include "thread/SCXThread.h"

NS_SCX_BEGIN
typedef enum{
	SCXSimpleRPCGetHeaderSizeStep,
	SCXSimpleRPCRecvHeaderStep,
	SCXSimpleRPCRecvBodyStep
}SCXSimpleRPCRecvStep;

typedef enum
{
	SCXSimpleRPCDidConnectResult,
	SCXSimpleRPCDidDisconnnect,
	SCXSimpleRPCDidOneRPCDataFinish,
	SCXSimpleRPCDestory
}SimpleRPCMsgType;

typedef enum{
	SCXSimpleRPCSelectConnect,
	SCXSimpleRPCSelectConnecting,
	SCXSimpleRPCReadAndWrite
}SCXSimpleRPCSelectIOStep;

class SimpleRPC;

class SCX_CORE_DLL SimpleRPCMsg : public RunLoopObserver{

public:

	SimpleRPCMsg();

	~SimpleRPCMsg();

	void setType(SimpleRPCMsgType type);

	SimpleRPCMsgType getType();

	bool getIsSuccess();

	void setIsSuccess(bool isSuccess);

	void setRPCData(RPCData* data);

	RPCData* getRPCData();

	void setSimpleRPC(SimpleRPC* rpc);

public:

	virtual void operate();

protected:

	SimpleRPCMsgType m_type;

	bool		m_isSuccess;

	RPCData*  m_rpcData;

	SimpleRPC* m_simpleRPC;
};


class SCX_CORE_DLL SimpleRPCDelegate
{
public:

	virtual void didConnectResult(SimpleRPC* rpc, bool isSuccess){}

	virtual void didDisconnect(SimpleRPC* rpc){}

	virtual SocketData* getHeartBeatData(SimpleRPC* rpc){return nullptr;}

	virtual int getHeaderSize(SimpleRPC* rpc){return 0;}

	virtual void didHeaderFinished(SimpleRPC* rpc, SocketData* data){}

	virtual int getBodySize(SimpleRPC* rpc, SocketData* data){return 0;}

	virtual void didOnePRCDataFinish(SimpleRPC* rpc, RPCData* data){}
    
    virtual ~SimpleRPCDelegate(){}
};

class SCX_CORE_DLL SimpleRPC : public Ref, public ThreadDelegate
{
public:

	SimpleRPC();

	~SimpleRPC();

	void init(const char* host, int port);

	void start();

	void restart();

	void stop();

	void destory();

	void sendData(unsigned char* data, int size);

	void sendData(SocketData* data);

	void setHeartBeatTime(int time);

	void setConnectTimeout(int cnnnTime);

	void setRecvTimeout(int recvTime);

	int getPort();

	const char* getHost();

	bool isConnect();

	bool isConnecting();

public:

	void run(Thread* thread);

public:

	virtual void didConnectResult(bool isSuccess);

	virtual void didDisconnect();

	virtual void didRecvData(unsigned char* data, int size);

public:

	void setDelegate(SimpleRPCDelegate* _delegate);

	void rpcRunloop(SimpleRPCMsg* msg );

protected:

	void pushSendData(SocketData* data);

	SocketData* frontData();

	void popData();

	bool sendData();

protected:

	int selectConnect();

	int selectConnecting();

	int slectReadAndWrite(unsigned char* buffer, int size);

protected:

	int selectSuccess(unsigned char* buffer, int size);

	int selectTimeout();

	int selectFail();

	void scheduleRecvTimeout();

	void recvTimeoutCallback(float time);

protected:

	void clean();

protected:

	std::queue<SocketData*> m_queueData;

protected:

	std::string   m_host;

	int			  m_port;

	SimpleRPCDelegate* m_delegate;

protected:

	SCXSimpleRPCRecvStep m_recvStep;

	Mutex				m_lock;

	RPCData*			m_curData;

protected:

	int					m_connectTimeout;//�������

	int					m_recvTimeout;//�������

	int				    m_heartBeatTime;

	bool				m_isConnect;

	bool				m_isConnecting;

	bool				m_destory;

	bool				m_isDisconnect;

	timeval				m_lastRecvTime;

protected:

	Selector* m_selector;

	SocketChannel* m_socketChannel;

	Thread		 m_thread;

	float		m_timeElapse;

	SCXSimpleRPCSelectIOStep m_selectStep;//0��ʼ����,1������, 2�����׶�
};
NS_SCX_END

#endif
