#include "SCXSocketChannel.h"
#include "CCStdC.h"

#ifdef WIN32
#include <windows.h>
#include <WinSock.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment( lib, "ws2_32.lib" )
#pragma comment( lib, "libzlib.lib" )
#else
#include <sys/socket.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>

#endif

NS_SCX_BEGIN
#ifdef WIN32
static bool g_isWinSockLibInit = false;
#endif

SocketChannel* SocketChannel::open(){
	SocketChannel* channel = new SocketChannel();
	channel->init();
	return channel;
}

SocketChannel::SocketChannel(){
	m_socket = -1;
	m_selectionKey = 0;
	m_readSet = nullptr;
	m_writeSet = nullptr;
	m_isBlock = false;
}

SocketChannel::~SocketChannel(){

}

void SocketChannel::init(){
#ifdef WIN32
	if(!g_isWinSockLibInit){
		WSADATA wsaData;
		WORD version = MAKEWORD(2, 2);
		WSAStartup(version, &wsaData);//win sock start up
		g_isWinSockLibInit = true;
	}
#endif

	
}

SocketChannel* SocketChannel::configureBlocking(bool blocking){
	if (-1 == m_socket)
	{
		m_isBlock = blocking;
		return this;
	}
#ifdef WIN32
	unsigned long mode = blocking ? 0 : 1;
	ioctlsocket(m_socket, FIONBIO, &mode);
#else
	
	int flags = fcntl(m_socket, F_GETFL, 0);
	if(!blocking)
		flags = flags | O_NONBLOCK;
	else
		flags = flags & ~O_NONBLOCK;
	fcntl(m_socket,F_SETFL, flags);	
	
#endif

	return this;
}

void SocketChannel::resister(Selector* selector, int opt){
	m_selectionKey = opt;
	selector->insert(this);
}

int SocketChannel::read(unsigned char* data, int len){
	return (int)recv(m_socket, (char*)data, len, 0);
}

int SocketChannel::write(unsigned char* data, int len){
	return (int)send(m_socket, (char*)data, len, 0);
}

int SocketChannel::selectionKey(){
	return m_selectionKey;
}

int SocketChannel::socket(){
	return m_socket;
}

void SocketChannel::connect(const char* host, int port)
{
	struct addrinfo* hint = NULL;
	struct addrinfo* res = NULL;

	::getaddrinfo(host, NULL, hint, &res);

	if (NULL == res)
		return;
	
	m_socket = ::socket(res->ai_family, SOCK_STREAM, IPPROTO_TCP);
	this->configureBlocking(m_isBlock);
	//unsigned long address = inet_addr(host);
	//if( INADDR_NONE == address)	{// ���IP��ַ��ʽ����
	//	in_addr addr;
	//	struct hostent* hp = gethostbyname(host);
	//	if(hp && hp->h_addr_list)	{
	//		memcpy(&addr, hp->h_addr_list[0], sizeof(in_addr));
	//		address = ::inet_addr(inet_ntoa(addr));	//�Զ�ȡ��һ������IP��
	//	}
	//}



	if (res->ai_family == AF_INET)
	{
		sockaddr_in* addr_in = (sockaddr_in*)res->ai_addr;
		addr_in->sin_port = htons(port);
		::connect(m_socket, res->ai_addr, res->ai_addrlen);
	}
	else
	{
		sockaddr_in6* addr_in = (sockaddr_in6*)res->ai_addr;
		addr_in->sin6_port = htons(port);
		::connect(m_socket, res->ai_addr, res->ai_addrlen);
	}

	
	::freeaddrinfo(res);
}

void SocketChannel::close(){
	if(-1 != m_socket){
#ifdef WIN32
		::shutdown(m_socket, SD_BOTH);
#else
		::shutdown(m_socket, SHUT_RDWR);
#endif
	}
	m_socket = -1;
	this->release();
}

bool SocketChannel::isConnectable(){
	if(!m_writeSet)
		return false;
	else 
		return  FD_ISSET(m_socket, m_writeSet) != 0;
}

bool SocketChannel::isReadable(){
	if(!m_readSet)
		return false;
	else
		return FD_ISSET(m_socket, m_readSet) != 0;
}

bool SocketChannel::isWritable(){
	if(!m_readSet)
		return false;
	else
		return FD_ISSET(m_socket, m_writeSet) != 0;
}

void SocketChannel::setReadAnWriteSet(fd_set* readSet, fd_set* writeSet){
	m_readSet = readSet;
	m_writeSet = writeSet;
}
NS_SCX_END