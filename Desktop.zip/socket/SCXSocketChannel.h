////////////////////////////////////////////////////////////
// Copyright(c) 2015���ݲ�����������Ƽ����޹�˾
// Author��  zhuang yusong
// Created�� 2015/06/11
// Describe��socket��װ
////////////////////////////////////////////////////////////

#ifndef SCX_SOCKET_CHANNEL_H
#define SCX_SOCKET_CHANNEL_H

#include "SCXSelector.h"
NS_SCX_BEGIN
class SCX_CORE_DLL SocketChannel : public Ref{

public:

	static SocketChannel* open();

public:

	SocketChannel* configureBlocking(bool blocking);

	void resister(Selector* selector, int opt);

	int read(unsigned char* data, int len);

	int write(unsigned char* data, int len);

	int selectionKey();

	int socket();

	void connect(const char* host, int port);

	void close();

public:

	bool isConnectable();

	bool isReadable();

	bool isWritable();

	void setReadAnWriteSet(fd_set* readSet, fd_set* writeSet);

protected:

	SocketChannel();

	~SocketChannel();

	void init();

protected:

	int m_socket;

	int m_selectionKey;

	fd_set* m_readSet;

	fd_set* m_writeSet;

	bool m_isBlock;

public:

	static const int OP_READ  = 0x00000002;//2

	static const int OP_WRITE = 0x00000004;//4

	static const int OP_CONNECT = 0x00000008;//8

	static const int OP_ACCEPT  = 0x00000010;//16
};

NS_SCX_END

#endif
