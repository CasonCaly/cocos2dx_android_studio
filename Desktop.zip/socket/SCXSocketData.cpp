#include "SCXSocketData.h"
NS_SCX_BEGIN
SocketData::SocketData(){
	m_bufferSize = 0;
	m_dataSize = 0;
	m_data = nullptr;
	m_isReleaseRawData = true;
}

SocketData::~SocketData(){
	if (m_data && m_isReleaseRawData){
		free(m_data);
	}
}

void SocketData::setData(unsigned char* data, int size){
	if (data && size > 0){
		m_data = (unsigned char*)malloc(size);
		m_bufferSize = size;
		m_dataSize = size;
		memcpy(m_data, data, size);
	}
}

void SocketData::setDataNoCopy(unsigned char* data, int size){
	if (m_data && m_isReleaseRawData)
		free(m_data);
	m_data = data;
	m_bufferSize = size;
	m_dataSize = size;
}

unsigned char* SocketData::getData(){
	return m_data;
}

int SocketData::getBufferSize(){
	return m_bufferSize;
}

int SocketData::getDataSize(){
	return m_dataSize;
}

void SocketData::appendData(unsigned char* data, int size){
	if (nullptr == m_data){
		m_data = (unsigned char*)malloc(size);
		m_bufferSize = size;
		m_dataSize = size;
		memcpy(m_data, data, size);
	}
	else{
		if( (m_dataSize + size) > m_bufferSize){
			int newBufferSize = m_dataSize + size;
			m_data = (unsigned char*)realloc(m_data, newBufferSize);
			m_bufferSize = newBufferSize;
		}
		
		memcpy(m_data + m_dataSize, data, size);	
		m_dataSize += size;
	}
}

void SocketData::replaceData(int pos, unsigned char* data, int size){
	if (nullptr == m_data || pos > m_bufferSize)
		return;

	if (pos < 0)
		pos = 0;
	//������λ�ó������е����ݴ�С����ô����Ϊ���е����ݴ�С
	if (pos > m_dataSize)
		pos = m_dataSize;
	//������buffer�Ĵ�С������
	if (pos + size > m_bufferSize)
		size = m_bufferSize - pos;
	
	memcpy(m_data + pos, data, size);
	//��������ˣ���ô���޸Ĵ�С
	if ((pos + size) > m_dataSize)
		m_dataSize = pos + size;
}

void SocketData::allocData(int size){
	m_data = (unsigned char*)malloc(size);
	m_dataSize = 0;
	m_bufferSize = size;
}

void SocketData::setIsReleaseRawData(bool isRelease){
	m_isReleaseRawData = isRelease;
}

NS_SCX_END