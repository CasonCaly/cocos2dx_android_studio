////////////////////////////////////////////////////////////
// Copyright(c) 2015���ݲ�����������Ƽ����޹�˾
// Author��  zhuang yusong
// Created�� 2015/06/11
// Describe��socket���ݷ�װ
////////////////////////////////////////////////////////////

#ifndef SCX_SOCKET_DATA_H
#define SCX_SOCKET_DATA_H
#include "SCXCoreSetting.h"

NS_SCX_BEGIN
class SCX_CORE_DLL SocketData : public Ref
{
public:

	SocketData();

	~SocketData();

	void setData(unsigned char* data, int size);

	void setDataNoCopy(unsigned char* data, int size);

	unsigned char* getData();

	int getBufferSize();

	int getDataSize();

	void appendData(unsigned char* data, int size);

	void replaceData(int pos, unsigned char* data, int size);

	void allocData(int size);

	void setIsReleaseRawData(bool isRelease);

protected:

	unsigned char* m_data;

	int			   m_bufferSize;

	int			   m_dataSize;

	bool		   m_isReleaseRawData;
};
NS_SCX_END
#endif
